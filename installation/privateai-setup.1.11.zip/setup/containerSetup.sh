#!/bin/bash

# File
#   containerSetup.sh
# Description
#   Setups and runs a container from given folder

# Set container software
# Defaults to podman, user can select their own
CONTAINER_SOFTWARE=podman

# Set project root directory
BASEDIR=$(dirname `readlink -f $0`)
source $BASEDIR/util.sh

REPO_URL=container-registry.oracle.com/database
OML_IMAGE_NAME=private-ai

PRINT_USAGE(){
  echo "$0 [options]"
  echo "Options:"
  echo "    -d, --directory <directory-path>        Private AI directory"
  echo "    -p, --port <port>                       Set port number"
  echo "    -r, --repo <repository>                 Repo storing the image, default container-registry.oracle.com/database"
  echo "    -v, --version <image-version>           Private-AI image version"
  echo "    -n, --name <Container-name>             Name used for container, default privateai"
  echo "    --http                                  Enable http connection, mutually exclusive with --https"
  echo "    --https                                 Enable https connection, mutually exclusive with --http"
  echo "                                            Default connection HTTPS"
  echo "    -h, --help, -help                       Print these options"
}

HTTP_ON=false

while [[ $# -gt 0 ]]
do
  key="$1"
  case "$key" in
  -h|--help|-help)
  PRINT_USAGE
  exit 0
  shift
  ;;
  -d|--directory)
  PAI_DIR="$2"
  shift
  shift
  ;;
  -r|--repo)
  REPO_URL="$2"
  shift
  shift
  ;;
  -p|--port)
  pai_port="$2"
  shift
  shift
  ;;
  -v|--version)
  image_ver="$2"
  shift
  shift
  ;;
  -n|--name)
  container_name="$2"
  shift
  shift
  ;;
  --http)
  HTTP_ON=true
  shift
  ;;
  --https)
  HTTPS_ON=true
  shift
  ;;
  *)
  print_error "Unknown option: \"$1\""
  PRINT_USAGE
  exit 1
  shift
  ;;
  esac
done

# Throw error if no working directory was passed
verify_dir "$PAI_DIR" false "Error with PrivateAI directory: [$PAI_DIR]\n\tRun -h, or --help for help"
check_dir_empty "$PAI_DIR" "Empty Private AI directory"

if [[ -d "$PAI_DIR/Models" && -z "$(ls -A "$PAI_DIR/Models")" ]]; then
  print_error "Empty model directory"
  exit 1
fi

# Get latest built image version
default_image_ver=25.1.0.0.0

if [[ -z "$REPO_URL" ]]; then
  print_error "Empty repository URL"
  exit 1
fi

if [[ -z "$OML_IMAGE_NAME" ]]; then
  print_error "Empty image name"
  exit 1
fi

if [[ "$PAI_DIR" != /* ]]; then
  PAI_DIR=$(pwd)/"$PAI_DIR"
fi
# Set external configuration from parameters
IMAGE_NAME="$REPO_URL/$OML_IMAGE_NAME:${image_ver:-$default_image_ver}"

# Set values from parameters, or default values if no values were passed
if [[ "$HTTPS_ON" == true && "$HTTP_ON" == true ]]; then
  print_error "Both HTTP and HTTPS were configured, but only one protocol can be used\n\tFailed to start the container"
  exit 1
fi
if [[ $HTTP_ON == true ]]; then
  PAI_PORT="-p ${pai_port:-"8080"}:8080"
  port_msg="HTTPS connection enabled: false"
  HTTPS_ON=false
else
  PAI_PORT="-p ${pai_port:-"8443"}:8443"
  port_msg="HTTPS connection enabled: true"
  HTTPS_ON=true
fi
if [[ "$HTTPS_ON" == true ]]; then
  verify_dir "$PAI_DIR/Security" false "HTTPS enabled but there is no security directory"
  check_dir_empty "$PAI_DIR/Security" "HTTPS enabled but security directory is empty"
  SECURITY_VAL="-v $PAI_DIR/Security:/privateai/ssl:z --secret keystore --secret privateai-ssl-pwd --secret api-key"
fi
CONTAINER_NAME=${container_name:-"privateai"}

if [[ -d "$PAI_DIR/Models" ]]; then
  MODELS_VAL="-v $PAI_DIR/Models:/privateai/models:z"
fi

# If no config file exists, do not pass, to use default models
if [[ -f "$PAI_DIR/Config/config.json" ]]; then
  CONFIG_VAL="-v $PAI_DIR/Config:/privateai/config:z -e OML_CONFIG_FILE=config.json"
fi

echo "Using image version ${image_ver:-$default_image_ver}"
echo "$port_msg"

# Stop previous container if running
$CONTAINER_SOFTWARE rm -f $CONTAINER_NAME > /dev/null 2>&1

# Check disk space in G for the container
DISK_SPACE=$(df -BG . --output=avail | tail -1)
if [[ "${DISK_SPACE%?}" -lt 12 ]]; then
  print_error "Insufficient disk space"
  exit 1
elif [[ "${DISK_SPACE%?}" -lt 22 ]]; then
  print_warning "Low disk space\n\tRecommended at least 22G of free space"
fi

# Check available memory in G for the container
MEM_SPACE=$(free -g | tail -2 | head -1 | awk '{print $2}')
if [[ "$MEM_SPACE" -lt 6 ]]; then
  print_error "Insufficient memory\n\tUse 6G or higher"
  exit 1
elif [[ "$MEM_SPACE" -lt 16 ]]; then
  print_warning "Low memory\n\tRecommended at least 16G of system memory"
fi


$CONTAINER_SOFTWARE run -d --name $CONTAINER_NAME           \
  -e OML_AUTHENTICATION_ENABLED=true           \
  -e OML_SSL_CERT_TYPE=PKCS12                  \
  -e OML_HTTPS_ENABLED="$HTTPS_ON"             \
  -e OML_MAX_SCORE_PAYLOAD=20000000            \
  -e OML_MAX_BATCHSIZE=256                     \
  $MODELS_VAL                                  \
  $CONFIG_VAL                                  \
  $SECURITY_VAL                                \
  -v $PAI_DIR/Logs:/privateai/logs:z           \
  $PAI_PORT                                    \
  $IMAGE_NAME > /dev/null
error_check $? "Could not start container"

# Check if the container was created correctly and appears in the container list
sleep 5
if [[ -z $($CONTAINER_SOFTWARE ps | grep -w $CONTAINER_NAME) ]]; then
  print_error "Problem starting container\n\tCheck the container logs at $PAI_DIR/Logs"
  exit 1
fi

print_success "Container started"