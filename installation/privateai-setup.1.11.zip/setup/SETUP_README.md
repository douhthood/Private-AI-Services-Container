# Setup Scripts

Scripts designed for the container admins to easily and quickly
set up a privateai container. 

- Create certificates.
- Create container secrets.
- Copy models, configurations, and certificates to
directory owned by the Private AI user.
- Start the Private AI container with the given data.

## Before you start

Verify that you have the following software installed:
- Oracle Linux 8, 9 or 10
- OpenSSL with TLS support
- Podman 4.9.4+
- PrivateAI image loaded on podman

To download the container image, you must be logged in to https://container-registry.oracle.com/ords/ocr/ba/database/private-ai
To log in you must generate an authentication token and use it as your password.
- Login to container-registry
- Access your profile
- Select Auth token
- Generate and copy secret key
- Login with podman using account and secret key `podman login https://container-registry.oracle.com/ords/ocr/ba/database/private-ai`

You can follow the guide: https://docs.oracle.com/en/operating-systems/oracle-linux/podman/registries.html#registry_ocr_token.

## Quick start

This guide will help you set up the PrivateAI container.
These scripts will help container administrators to set up the 
container. It will facilitate the certificates and secret generation. As
well as setting up a directory that will be owned by the PrivateAI container.

The script `quickStart.sh` can be modified to have the paths the administrator
will use for the different directories, it can be modified to run all three scripts at a time.

Below is an example using bash terminal, it is the simplest way, using default models.
Parameters can be viewed in each script section.

To start make sure you have a PrivateAI image and OpenSSL installed.

```shell
# To start make sure you have a PrivateAI image and OpenSSL installed.
# Set up directory paths
export SECRETS_DIR=/path/to/secrets/
export PRIVATEAI_DIR=/path/to/privateai/folder/

./secretsSetup.sh -s $SECRETS_DIR
./configSetup.sh -s $SECRETS_DIR -d $PRIVATEAI_DIR
./containerSetup.sh -d $PRIVATEAI_DIR
```

This example creates certificates, sets up a folder for use with the container and  starts the container with the
latest installed image, with name privateai. The default connection settings is HTTPS enabled on port 8443.
When HTTP is enabled the default port is 8080. HTTPS and HTTP connections are exclusive between each other,
so enabling HTTP disables HTTPS and enabling HTTPS disables HTTP.

---

The full list of options is as follows:

```shell
./secretsSetup.sh -s /path/to/secrets/ \
                  --subj "Subject DN String" \
                  --pass /path/to/password/file
./configSetup.sh -d /path/to/privateai/folder/ \
                 -s /path/to/secrets/ \
                 -m /path/to/models/ \
                 -c /path/to/conf/config.json \
                 -u <Container UID>
./containerSetup.sh -d /path/to/privateai/folder/ \
                    -p <PRIVATEAI-PORT> \
                    -r <REPOSITORY> \
                    -v <IMAGE_VERSION> \
                    --http | --https \
                    -n <CONTAINER-NAME>
```

The end result of this is a running container with the models the user specified, from there
the user is free to use the container as needed.

---

## Secrets Setup

Sets up secrets and certificates needed to launch the container
and stores them in a folder specified by the user, if the folder
does not exist the script will generate it.

The user is able to pass subject DN as a string and password as a file,
to avoid user input during execution of the script.

### Arguments

- `-s, --secrity /path/to/secrets/` Directory where certificates will be generated
- `--subj "Subject DN String"` String to pass as OpenSSL subj parameter
- `--pass /path/to/password/file` File that contains password for keystore and container secret

### Usage

```shell
./secretsSetup.sh -s /path/to/secrets/
```

```shell
./secretsSetup.sh -s /path/to/secrets/ \
    --subj "/C=US/ST=California/L=Redwood City/O=Oracle Corporation/OU=DBDEV/CN=example.oracle.com"
```

```shell
./secretsSetup.sh -s /path/to/secrets/ \
    --subj "/C=US/ST=California/L=Redwood City/O=Oracle Corporation/OU=DBDEV/CN=example.oracle.com" \
    --pass /path/to/password/file
```

---

## Config Setup

The user passes directories with models, secrets and configuration file,
and the script copies them to another folder specified by the user, if this directory does
not exist the script will generate it, creates a
folder for log files and changes the owner to the host UID of the specified container
UID (default 2001), to permit logging by the container.

### Arguments
- `-m, --models-dir <Models-Directory-Path>` Directory with model files
- `-s, --security <Security-Directory>` Directory with certificates, directory setup by `secretSetup.sh`
- `-c, --conf-file <Config-File-Path>` Path for configuration .json file
- `-u, --uid <Container User-ID>` UID in container, defaults to 2001
- `-d, --directory <PrivateAI-Directory>` Directory where the given elements will be copied to, the owner will be changed to host UID.

### Usage

```shell
./configSetup.sh -s /path/to/secrets/ -d /path/to/privateai/folder/
```

In this first case, the container ships with default models, so models and config file can be skipped.

```shell
./configSetup.sh -s /path/to/secrets/ -m /path/to/models/ -c /path/to/conf/config.json -d /path/to/privateai/folder/
```

```shell
./configSetup.sh -s /path/to/secrets/ -m /path/to/models/ -c /path/to/conf/config.json -u <UID> -d /path/to/privateai/folder/
```

---

## Container Setup

The user passes the directory with the copied files. This directory will be owned by the
Host UID that corresponds to the Container UID, letting the container write the needed logs.

### Arguments

- `-d, --directory <directory>` Path to the directory for use in the container, should include the following
folders: Models, Security, Config (with a config.json file) and Logs. All owned by the host UID corresponding to
the container UID. Can be generated by `configSetup.sh`.
- `-p, --port <privateai-port-number>` Port number in use for container, defaults to 8080 for `-http` or 8443 for `--https`.
- `-r, --repo <repository>`: URL for the repository where the image will be pulled from, defaults to `container-registry.oracle.com/database`
- `-v, --version <Image-version>` PrivateAI image version to use, defaults to latest built container image
- `-n, --name <Container-Name>` Name for the container, default privateai
- `--https` Enable HTTPS connection, exclusive with `--http`.
- `--http` Enable HTTP connection, exclusive with `--https`.

`--http` and `--https` are mutually exclusive, if both parameters are passed the startup will fail.
Defaults to HTTPS.

### Usage

```shell
./containerSetup.sh -d /path/to/privateai/folder/
```

```shell
./containerSetup.sh -d /path/to/privateai/folder/ -v 1.11.7
```

```shell
./containerSetup.sh -d /path/to/privateai/folder/ -v 1.11.7 -p 9090
```

```shell
./containerSetup.sh -d /path/to/privateai/folder/ -v 1.11.7 -p 9090
```

```shell
./containerSetup.sh -d /path/to/privateai/folder/ -v 1.11.7 -p 9090 -n "privateai-test"
```

---

## How to make calls to the container

The following are examples of curl calls that can be made to the container. It provides examples in both
HTTP and HTTPS modes. It assumes the ports are the default 8080 for HTTP and 8443 for HTTPS.
In HTTPS calls replace `[API-KEY]` with the key generated by `secretsSetup.sh`.

### Verify the service is running using health endpoint

```shell
curl -i http://localhost:8080/health
```
```shell
curl -i --cacert /path/to/privateai/folder/Security/cert.pem \
     --header "Authorization: Bearer [API-KEY]" \
     https://localhost:8443/health
```
For this call use `-i` to get the status returned by the call.

**Example Output**

```shell
HTTP/1.1 200 OK
date: Fri, 3 Oct 2025 22:34:30 GMT
x-ratelimit-limit-requests: 60
x-ratelimit-remaining-requests: 59
x-ratelimit-reset-requests: 1
x-server-id: 12a5d184-d4fc-4655-8f33-a20d28ca5efe
content-length: 0
```

### Requesting a list of the models in the container

```shell
curl http://localhost:8080/v1/models
```
```shell
curl --cacert /path/to/privateai/folder/Security/cert.pem \
     --header "Authorization: Bearer [API-KEY]" \
     http://localhost:8080/v1/models
```

**Example Output**

```json
{
  "data":[
    {
      "id":"clip-vit-base-patch32-img",
      "modelDeployedTime":"2025-10-09T18:18:46.846958268Z",
      "modelSize":"335.38M",
      "modelCapabilities":["IMAGE_EMBEDDINGS"],
      "is_default":false
    },
    {
      "id":"clip-vit-base-patch32-txt",
      "modelDeployedTime":"2025-10-09T18:18:48.049771828Z",
      "modelSize":"243.57M",
      "modelCapabilities":["TEXT_EMBEDDINGS"],
      "is_default":false
    }
  ]
}
```

### Request information on a specific model

```shell
curl http://localhost:8080/v1/models/{id}
```

```shell
curl --cacert /path/to/privateai/folder/Security/cert.pem \
     --header "Authorization: Bearer [API-KEY]" \
     https://localhost:8443/v1/models/{id}
```

**Example Output on Clip Text Model**

```json
{
  "id":"clip-vit-base-patch32-txt",
  "modelDeployedTime":"2025-10-09T18:18:48.049771828Z",
  "modelSize":"243.57M",
  "modelCapabilities":["TEXT_EMBEDDINGS"],
  "is_default":false
}
```

### Embedding calls

```shell
curl --header "Content-Type: application/json" \
     -d '{"model": "{id}", "input": ["The quick brown fox jumped over the fence.","Another test sentence"]}' \
     http://localhost:8080/v1/embeddings
```

```shell
curl --cacert /path/to/privateai/folder/Security/cert.pem \
     --header "Content-Type: application/json" \
     --header "Authorization: Bearer [API-KEY]" \
     -d '{"model": "{id}", "input": ["The quick brown fox jumped over the fence.","Another test sentence"]}' \
     https://localhost:8443/v1/embeddings
```

### Calling metrics

**Calling metrics without filters**

```shell
curl --header "Content-Type: application/json" \
     http://localhost:8080/metrics/{metric}
```

```shell
curl --cacert /path/to/privateai/folder/Security/cert.pem \
     --header "Content-Type: application/json" \
     --header "Authorization: Bearer [API-KEY]" \
     https://localhost:8443/metrics/{metric}
```

**Calling metrics with model filter**

```shell
curl --header "Content-Type: application/json" \
     http://localhost:8080/metrics/{metric}?tag=model:{id}
```

```shell
curl --cacert /path/to/privateai/folder/Security/cert.pem \
     --header "Content-Type: application/json" \
     --header "Authorization: Bearer [API-KEY]" \
     https://localhost:8443/metrics/{metric}?tag=model:{id}
```

**Calling metrics with model and container filter**

```shell
curl --header "Content-Type: application/json" \
     http://localhost:8080/metrics/{metric}?tag=model:{id}&tag=container.id:{container-id}
```

```shell
curl --cacert /path/to/privateai/folder/Security/cert.pem \
     --header "Content-Type: application/json" \
     --header "Authorization: Bearer [API-KEY]" \
     https://localhost:8443/metrics/{metric}?tag=model:{id}&tag=container.id:{container-id}
```

**Example Output with no filters**

```json
{
  "name":"embeddings_call_latency",
  "measurements":[
    {
      "statistic":"COUNT",
      "value":1.0
    },
    {
      "statistic":"TOTAL_TIME",
      "value":0.912
    },
    {
      "statistic":"MAX",
      "value":0.0
    }],
  "availableTags":[
    {
      "tag":"model",
      "values":["clip-vit-base-patch32-txt"]
    },
    {
      "tag":"container.id",
      "values":["7c1d0922-eb4c-4d2b-8ef6-e25861c64f6c"]
    },
    {
      "tag":"status","values":["success"]
    }],
  "description":"Call latency in milliseconds",
  "baseUnit":"seconds"
}
```

## Trouble Shooting

### IP Address vs FQDN for self-signed certificates

When generating your self-signed certificate you will be asked for the common name
of the domain you will be using. Here you can pass either an IP address or FQDN. The main
difference involves the fact that FQDN will point to dynamic IP addresses. So if you need
to access a direction that will not change or remain static, it may be better to use
IP address. Additionally, if your server has load balancer or virtual hosting, it may be a requirement
to use FQDN instead of IP address.

### What to do if your certificate are expired

When the certificate you use for the curl requests expires, You will encounter an error 
related to security and not be able to make requests to the container. To fix this
issue, you must generate new certificates and restart the container.

### How to change API key without creating a new self-signed certificate

The certificates and API key are separate from each other, and you can generate a new API key
and link it to the container without needing to modify security directories. To do this you can run
the following commands. It assumes the container is named privateai and that you are using podman, modify as needed.

```shell
podman stop privateai
podman secret rm api-key
head -c 32 /dev/urandom | xxd -p | tr -d '\n' | head -c 64 > api-key.txt
podman secret create api-key api-key.txt
./containerSetup.sh -d /path/to/privateai/folder
```

