#!/bin/bash

#Complete this section as needed
# Set up the path variables
SECRETS_DIR=/path/to/secrets/
PRIVATEAI_DIR=/path/to/privateai/folder
MODELS_DIR=/path/to/models/
CONFIG_FILE=/path/to/conf/config.json

# Path to password file
PWD_FILE=/path/to/password/file
# OpenSSL Subject DN String
SDN_STRING="/C=US/ST=California/L=Redwood City/O=Oracle Corporation/OU=DBDEV/CN=example.oracle.com"

# Default values can be left as is or changed as needed
# UID corresponding to the container
HOST_UID=2001
PRIVATEAI_PORT=8443
CONNECTION=--https
REPO_URL=container-registry.oracle.com/database
IMAGE_VER=25.1.0.0.0
CONTAINER_NAME="privateai"

script_location=$(dirname $(realpath "$0"))

$script_location/secretsSetup.sh -s "$SECRETS_DIR" --subj "$SDN_STRING" --pass "$PWD_FILE"
$script_location/configSetup.sh -s "$SECRETS_DIR" -d "$PRIVATEAI_DIR" -m "$MODELS_DIR" -c "$CONFIG_FILE" -u "$HOST_UID"
$script_location/containerSetup.sh -d "$PRIVATEAI_DIR" -r "$REPO_URL" -v "$IMAGE_VER" -n "$CONTAINER_NAME" -p "$PRIVATEAI_PORT" "$CONNECTION"
