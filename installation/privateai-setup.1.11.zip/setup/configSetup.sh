#!/bin/bash

# File
#   configSetup.sh
# Description
#   Script that copies directories provided from the user
#   into directories for use by the container

# Set container software
# Defaults to podman, user can select their own
CONTAINER_SOFTWARE=podman

# Set project root directory
BASEDIR=$(dirname `readlink -f $0`)
source $BASEDIR/util.sh

# Function:
#   PRINT_USAGE
# Description:
#   Display script usage
PRINT_USAGE() {
  echo "Setup folders for Private AI Container"
  echo ""
  echo "Usage:"
  echo "  $0 [options]"
  echo ""
  echo "Options:"
  echo "  -m, --models-dir <models-dir>          Models directory"
  echo "  -s, --security <secrets-dir>           Secrets directory"
  echo "  -c, --conf-file <config-file>          Configuration file location"
  echo "  -d, --directory <privateai-dir>        Directory for PrivateAI data"
  echo "  -u, --uid <container-user-id>          Set container UID to map to host UID"
  echo "  -h, --help, -help                      Print this usage info"
  echo ""
}

CLEAN_UP() {
  # Clean up folders if any
  sudo rm -rf "$WORK_DIR/Models"
  sudo rm -rf "$WORK_DIR/Config"
  sudo rm -rf "$WORK_DIR/Security"
  sudo rm -rf "$WORK_DIR/Logs"

  # Create/copy folders for use in Private AI Container
  mkdir "$WORK_DIR/Config"
  mkdir "$WORK_DIR/Logs"
}

CHANGE_OWNERSHIP() {
  DIR=$1
  sudo chown -R "$HOST_UID" "$DIR"
  sudo chgrp -R "$HOST_UID" "$DIR"
  sudo chmod -R "$2" $DIR
}

# Setup directory values
MODELS_DIR=""
SECURITY_DIR=""
CONF_FILE=""
WORK_DIR=""
CONTAINER_UID=2001

while [[ $# -gt 0 ]]
do
key="$1"
case $key in
    -m|--models-dir)
    MODELS_DIR="$2"
    shift
    shift
    ;;
    -s|--security)
    SECURITY_DIR="$2"
    shift
    shift
    ;;
    -c|--conf-file)
    CONF_FILE="$2"
    shift
    shift
    ;;
    -d|--directory)
    WORK_DIR="$2"
    shift
    shift
    ;;
    -u|--uid)
    CONTAINER_UID="$2"
    shift
    shift
    ;;
    -h|--help|-help)
    PRINT_USAGE
    exit 0
    shift
    ;;
    *)
    print_error "Unrecognized command \"$1\""
    PRINT_USAGE
    exit 1
    shift
    ;;
esac
done

# Throw error if no working directory was passed
verify_dir "$WORK_DIR" true "Error with PrivateAI directory: [$WORK_DIR], verify that path is accessible and not empty\n\tRun -h, or --help for help"

# Throw error if config file is not a file
if [[ -n "$CONF_FILE" && ! -f "$CONF_FILE" ]]; then
  print_error "Error with config file: $CONF_FILE is not found"
  exit 1
fi

CLEAN_UP

mapfile -t UID_MAP < <($CONTAINER_SOFTWARE unshare cat /proc/self/uid_map)

for line in "${UID_MAP[@]}"; do
  set -- $line
  CONTAINER_START=$1
  HOST_START=$2
  COUNT=$3
  if (( $CONTAINER_UID >= $CONTAINER_START && $CONTAINER_UID < $CONTAINER_START + $COUNT )); then
    HOST_UID=$(( $HOST_START + ($CONTAINER_UID - $CONTAINER_START) ))
    print_success "Container UID $CONTAINER_UID maps to Host UID $HOST_UID"
  fi
done

if [[ -z $HOST_UID ]]; then
  print_error "No mapping found for container UID $CONTAINER_UID"
  exit 1
fi

# Change owner of the folders and give write permissions
if [[ -n "$MODELS_DIR" ]]; then
  verify_dir "$MODELS_DIR" false "Passed model directory $MODELS_DIR does not exist"
  cp -R "$MODELS_DIR" "$WORK_DIR/Models"
  CHANGE_OWNERSHIP "$WORK_DIR/Models" u+r
  print_success "Copied PrivateAI model directory"
fi

if [[ -n "$SECURITY_DIR" ]]; then
  cp -R "$SECURITY_DIR" "$WORK_DIR/Security"
  CHANGE_OWNERSHIP "$WORK_DIR/Security" u+r
  print_success "Copied PrivateAI security directory"
else
  print_warning "No security directory passed"
fi

if [[ -n "$CONF_FILE" ]]; then
  cp "$CONF_FILE" "$WORK_DIR/Config/config.json"
  print_success "Copied PrivateAI config file"
fi
CHANGE_OWNERSHIP "$WORK_DIR/Config" u+r
CHANGE_OWNERSHIP "$WORK_DIR/Logs" u+rw

print_success "Generated PrivateAI logs directory"