#!/bin/bash

# File
#   secretsSetup.sh
# Description
#   Run this script to setup secrets for Private AI container

# Set container software
# Defaults to podman, user can select their own
CONTAINER_SOFTWARE=podman

# Set project root directory
BASEDIR=$(dirname `readlink -f $0`)
source $BASEDIR/util.sh

PRINT_USAGE() {
  echo "Generate certificate files and container secrets"
  echo "Usage:"
  echo "    $0 [Options]"
  echo "Options"
  echo "    -s, --security <Security-Dir> Directory to store certificates"
  echo "    --subj <subj String> OpenSSL subject Distinguished Name"
  echo "    --pass <Password file> File with password for keystore and secret"
  echo "    -h Display help options"
}

CLEAN_DIR() {
  # Clean up of previous secrets
  rm -rf "$WORKING_DIR/run"
  rm -f "$WORKING_DIR/key.pem"
  rm -f "$WORKING_DIR/key.pub"
  rm -f "$WORKING_DIR/cert.pem"
  rm -f "$WORKING_DIR/api-key"
  rm -rf "$WORKING_DIR/secrets"

  mkdir "$WORKING_DIR/secrets"
}
# Create a container secret
CREATE_SECRET() {
  $CONTAINER_SOFTWARE secret rm -i "$1" > /dev/null 2>&1
  $CONTAINER_SOFTWARE secret create "$1" "$2" > /dev/null
  error_check $? "Could not create secret $1"
}

while [[ $# -gt 0 ]]
do
  key="$1"
  case $key in
    -s|--security)
      WORKING_DIR=$2
      shift
      shift
      ;;
    --subj)
      SDN=$2
      shift
      shift
      ;;
    --pass)
      PASS=$2
      shift
      shift
      ;;
    -h)
      PRINT_USAGE
      exit 0
      ;;
    *)
      print_error "Unrecognized command \"$1\""
      PRINT_USAGE
      exit 1
      ;;
  esac
done

verify_dir "$WORKING_DIR" true "Error with security directory: [$WORKING_DIR], verify path is accessible and not empty"

# Check if a file was passed for password
if [[ ! -f "$PASS" && -n "$PASS" ]]; then
  print_error "Password file does not exist"
  exit 1
fi

CLEAN_DIR

# Key generation
head -c 32 /dev/urandom | xxd -p | tr -d '\n' | head -c 64 > ${WORKING_DIR}/api-key

openssl genrsa -out "$WORKING_DIR/key.pem" > /dev/null 2>&1
openssl rsa -in "$WORKING_DIR/key.pem" -out "$WORKING_DIR/key.pub" -pubout > /dev/null 2>&1
if [[ -z "$SDN" ]]; then
  openssl req -new -x509 -key "$WORKING_DIR/key.pem" -out "$WORKING_DIR/cert.pem" -days 365
else
  openssl req -new -x509 -key "$WORKING_DIR/key.pem" -out "$WORKING_DIR/cert.pem" -days 365 -subj="$SDN" > /dev/null 2>&1
fi
error_check $? "Could not generate certificate"
# Keystore generation

## Create container secret with password
if [[ -z "$PASS" ]]; then
  read -s -p "Enter keystore password: " PASS
  echo
  read -s -p "Confirm keystore password: " confirm
  if [[ "$PASS" != "$confirm" ]]; then
    echo
    print_error "Password does not match"
    exit 1
  fi
  echo
  echo "$PASS" > "$WORKING_DIR/secrets/privateai-ssl-pwd"
  openssl pkcs12 -export -inkey "$WORKING_DIR/key.pem" -in "$WORKING_DIR/cert.pem" -name mykey -out "$WORKING_DIR/keystore" -passout file:"$WORKING_DIR/secrets/privateai-ssl-pwd" > /dev/null 2>&1
  error_check $? "Could not generate keystore"
  CREATE_SECRET privateai-ssl-pwd "$WORKING_DIR/secrets/privateai-ssl-pwd"
else
  openssl pkcs12 -export -inkey "$WORKING_DIR/key.pem" -in "$WORKING_DIR/cert.pem" -name mykey -out "$WORKING_DIR/keystore" -passout file:"$PASS" > /dev/null 2>&1
  error_check $? "Could not generate keystore"
  CREATE_SECRET privateai-ssl-pwd "$PASS"
fi

# Create container secret with keystore
CREATE_SECRET keystore "$WORKING_DIR/keystore"

# Create container secret for api-key
CREATE_SECRET api-key "$WORKING_DIR/api-key"

mv run/ "$WORKING_DIR" 2>/dev/null

rm -rf "$WORKING_DIR/secrets/privateai-ssl-pwd"

print_success "Generated security directory at $WORKING_DIR"