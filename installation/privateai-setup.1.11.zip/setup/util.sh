#!/bin/bash

# STDOUT utilities

print_error(){
  local RED='\033[0;31m'
  local NC='\033[0m'
  echo -e "${RED}  FAIL: $1 ${NC}"
  echo
}

print_warning(){
  local YELLOW='\033[0;33m'
  local NC='\033[0m'
  echo -e "${YELLOW}  WARN: $1 ${NC}"
  echo
}

print_success(){
  local GREEN='\033[0;32m'
  local NC='\033[0m'
  echo -e "${GREEN}  SUCC: $1 ${NC}"
  echo
}

# Error handling

# Function:
#   error_check
# Description:
#   Check if a command exited with error and display error message.
# Example:
#   <some-command>
#   error_check $? "some error message"
error_check() {
  exit_code=$1
  error_msg=$2
  if [ $exit_code -ne 0 ]; then
    print_error "${error_msg}."
    exit $exit_code
  fi
}

# Directory Utils

# Function
#   verify_dir
# Description
#   Verify that directory exists and optionally generate the directory
# Example
#   verify_dir /some/dir
#   verify_dir /some/dir (true|false)
#   verify_dir /some/dir (true|false) "error message"
# Error message and -generate should be exclusive between each other
verify_dir() {
  DIR=$1
  GENERATE=${2,,:-true}
  MSG=$3
  if [[ $# -gt 3 ]]; then
    print_error "Too many arguments"
    exit 1
  fi
  if [[ "$GENERATE" != "true" && "$GENERATE" != "false" ]]; then
    print_error "Generate value error, pass true or false"
    exit 1
  fi
  if [[ -z "$DIR" ]]; then
    print_error "$MSG"
    exit 1
  fi
  if [[ "$GENERATE" == true && ! -d "$DIR"  ]]; then
    print_warning "Directory $DIR does not exist, generating..."
    mkdir "$DIR"
  elif [[ ! -d "$DIR" ]]; then
    print_error "Directory $DIR does not exist"
    print_error "$MSG"
    exit 1
  fi
}

# Function
#   check_dir_empty
# Description
#   Verify that the directory contains files or subdirectories
# Example
#   check_dir_empty /some/dir
#   check_dir_empty /some/dir "error message"
# Error message and -generate should be exclusive between each other
check_dir_empty(){
  DIR=$1
  MSG=$2
  if [[ -z "$DIR" ]]; then
    print_error "Empty path"
    exit 1
  elif [[ -z "$(ls -A "$DIR")" ]]; then
    print_error "$MSG"
    exit 1
  fi
}